create definer = lq@`%` view selectTeacher as
select `study`.`teacher`.`tno` AS `tno`, `study`.`teacher`.`tname` AS `tname`
from `study`.`teacher`
order by `study`.`teacher`.`tno` desc;

